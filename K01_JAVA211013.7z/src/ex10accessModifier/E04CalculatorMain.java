package ex10accessModifier;

public class E04CalculatorMain
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

}
