package ex10accessModifier.cal;

public class Calculator
{

}
