package quiz;

import java.util.Random;
import java.util.Scanner;

public class QuRockPaperScissors
{
	public static void gamestart() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("무엇을 내시겠습니까?");
		Random random = new Random();
		int gameCount = 0;
		
	}
	
	public static void main(String[] args)
	{
		
	}

}
