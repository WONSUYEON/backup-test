package ex04ControlStatement;

public class Qu_04_02_T {

	public static void main(String[] args) {
	
		{
			 int num = 120;
			 if (num > 0 && (num % 2) == 0) {
					System.out.println("양수이면서 짝수");
				}
			 else {
				 System.out.println("양수이면서 짝수가 아닙니다");
			 }
		 }
	




	}

}
